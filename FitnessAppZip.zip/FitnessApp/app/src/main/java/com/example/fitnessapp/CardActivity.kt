package com.example.fitnessapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class CardActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card)

        supportActionBar?.hide()

        val bmi = findViewById<ImageView>(R.id.imgBMI)
        val sensor = findViewById<ImageView>(R.id.imgPedoMeter)
        val chatAI = findViewById<ImageView>(R.id.imgChat)

        bmi.setOnClickListener {
            val i = Intent(this, BMIactivity::class.java)
            startActivity(i)
        }

        sensor.setOnClickListener {
            val i2 = Intent(this, PedoSensor::class.java)
            startActivity(i2)
        }

        sensor.setOnClickListener {
            val i3 = Intent(this, PersonalizeChat::class.java)
            startActivity(i3)
        }

    }
}